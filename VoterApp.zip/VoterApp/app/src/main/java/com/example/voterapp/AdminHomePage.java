package com.example.voterapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class AdminHomePage extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.adminhomepage);

    }
}
