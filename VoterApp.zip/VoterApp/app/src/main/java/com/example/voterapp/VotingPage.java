package com.example.voterapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class VotingPage extends AppCompatActivity {

    private RadioGroup radioGroup;
    private Button voteButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.votingpage);

        radioGroup = findViewById(R.id.radioGroup);
        voteButton = findViewById(R.id.button5);

        voteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(VotingPage.this, LoginActivity.class);
                startActivity(intent);
                int selectedId = radioGroup.getCheckedRadioButtonId();
            }
        });
    }
}
